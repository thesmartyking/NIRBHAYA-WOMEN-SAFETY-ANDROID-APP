package com.example.nirbhaya_womensafetyapp;

import android.Manifest;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.net.Uri;
import android.support.annotation.NonNull;
import android.support.design.widget.NavigationView;
import android.support.v4.app.ActivityCompat;
import android.support.v4.app.FragmentTransaction;
import android.support.v4.content.ContextCompat;
import android.support.v4.view.GravityCompat;
import android.support.v4.widget.DrawerLayout;
import android.support.v7.app.ActionBarDrawerToggle;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.Toolbar;
import android.telephony.SmsManager;
import android.util.Log;
import android.view.KeyEvent;
import android.view.MenuItem;
import android.view.View;
import android.widget.Switch;
import android.widget.Toast;


public class MainActivity extends AppCompatActivity implements NavigationView.OnNavigationItemSelectedListener {
    static private int counter=0;
    DrawerLayout mDrawerLayout;
    ActionBarDrawerToggle mDrawerToggle;
    DatabaseHelper myDb;
    int delay=1;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);


        myDb = new DatabaseHelper(this);

        // friends for toolbar we use v7 package

        Toolbar toolbar = findViewById(R.id.toolBar);
        setSupportActionBar(toolbar);

        mDrawerLayout = findViewById(R.id.drawerLayout);
        mDrawerToggle = new ActionBarDrawerToggle(this, mDrawerLayout, toolbar, R.string.open, R.string.close);

        mDrawerLayout.addDrawerListener(mDrawerToggle);
        mDrawerToggle.syncState();

        NavigationView navigationView = findViewById(R.id.nav_view);
        navigationView.setNavigationItemSelectedListener(this);


        HomeFragment fragment = new HomeFragment();
        FragmentTransaction fragmentTransaction = getSupportFragmentManager().beginTransaction();
        fragmentTransaction.replace(R.id.frame_layout, fragment, "Home");
        fragmentTransaction.commit();


    }

    @Override
    public boolean dispatchKeyEvent(KeyEvent event) {
        if (
               event.getKeyCode() == KeyEvent.KEYCODE_VOLUME_UP
                || event.getKeyCode() == KeyEvent.KEYCODE_VOLUME_DOWN
                || event.getKeyCode() == KeyEvent.KEYCODE_POWER
                ) {
            counter++;
        }
        if(event.getKeyCode() == KeyEvent.KEYCODE_BACK){
            if (mDrawerLayout.isDrawerOpen(GravityCompat.START)) {
                mDrawerLayout.closeDrawer(GravityCompat.START);
            }
            else {
                //Toast.makeText(MainActivity.this, "Back Pressed", Toast.LENGTH_SHORT).show();
                HomeFragment fragment = new HomeFragment();
                FragmentTransaction fragmentTransaction = getSupportFragmentManager().beginTransaction();
                fragmentTransaction.replace(R.id.frame_layout, fragment, "Home");
                fragmentTransaction.commit();
            }
        }
        if(counter>5){
            Switch switch1= (Switch) findViewById(R.id.switch1);
            if(switch1.isChecked()){
                counter=0;
                if(delay==1) {
                    delay=0;
                    GPS_Fragment_call fragment = new GPS_Fragment_call();
                    FragmentTransaction fragmentTransaction = getSupportFragmentManager().beginTransaction();
                    fragmentTransaction.replace(R.id.frame_layout, fragment, "CALLING...");
                    fragmentTransaction.commit();
                    Toast.makeText(this,"Calling..... \nSMS Sending.....",Toast.LENGTH_SHORT).show();
                    delay=1;
                }

            }

            counter=0;
            }

        return true;
    }

    @Override
    public boolean onNavigationItemSelected(@NonNull MenuItem menuItem) {

        int id = menuItem.getItemId();

        if (id == R.id.nav_home) {
            HomeFragment fragment = new HomeFragment();
            FragmentTransaction fragmentTransaction = getSupportFragmentManager().beginTransaction();
            fragmentTransaction.replace(R.id.frame_layout, fragment, "Home");
            fragmentTransaction.commit();
        }
        else if (id == R.id.nav_contacts) {
            ContactFragment fragment = new ContactFragment();
            FragmentTransaction fragmentTransaction = getSupportFragmentManager().beginTransaction();
            fragmentTransaction.replace(R.id.frame_layout, fragment, "EMERGENCY CONTACTS");
            fragmentTransaction.commit();

        }
       else if (id == R.id.nav_gps) {
            GPS_LocationFragment fragment = new GPS_LocationFragment();
            FragmentTransaction fragmentTransaction = getSupportFragmentManager().beginTransaction();
            fragmentTransaction.replace(R.id.frame_layout, fragment, "GPS LOCATION");
            fragmentTransaction.commit();
        }

        else if (id == R.id.nav_instruction) {
            InstructionFragment fragment = new InstructionFragment();
            FragmentTransaction fragmentTransaction = getSupportFragmentManager().beginTransaction();
            fragmentTransaction.replace(R.id.frame_layout, fragment, "INSTRUCTIONS");
            fragmentTransaction.commit();
        }

        /*else if (id == R.id.nav_tools) {
            Intent intent=new Intent(this,Exservice.class);
            intent.putExtra("EMERGENCY MODE -> ON","Click on Notification to Open App");
            startService(intent);

        }*/

        else if (id == R.id.nav_share) {
            AboutusFragment fragment = new AboutusFragment();
            FragmentTransaction fragmentTransaction = getSupportFragmentManager().beginTransaction();
            fragmentTransaction.replace(R.id.frame_layout, fragment, "ABOUT US");
            fragmentTransaction.commit();
        }
        else if (id == R.id.nav_send) {
            ContactusFragment fragment = new ContactusFragment();
            FragmentTransaction fragmentTransaction = getSupportFragmentManager().beginTransaction();
            fragmentTransaction.replace(R.id.frame_layout, fragment, "CONTACT US");
            fragmentTransaction.commit();
        }
        mDrawerLayout.closeDrawer(GravityCompat.START);
        return true;
    }



}

package com.example.nirbhaya_womensafetyapp;

import android.Manifest;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.content.res.ColorStateList;
import android.database.Cursor;
import android.graphics.Color;
import android.net.Uri;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.v4.app.ActivityCompat;
import android.support.v4.app.Fragment;
import android.support.v4.content.ContextCompat;
import android.support.v7.app.AlertDialog;
import android.telephony.SmsManager;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.CompoundButton;
import android.widget.Switch;
import android.widget.Toast;


/**
 * A simple {@link Fragment} subclass.
 */
public class HomeFragment extends Fragment {
    static int emerg=0;
    DatabaseHelper myDb;
    static Switch s123;
    public HomeFragment() {
        // Required empty public constructor

    }


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        getActivity().setTitle("NIRBHAYA-(WOMEN SAFETY APP)");
        myDb = new DatabaseHelper(getActivity());

        View view=inflater.inflate(R.layout.fragment_home, container, false);
        final Switch s123= (Switch) view.findViewById(R.id.switch1);
        if(emerg==1)
        {
            s123.setChecked(true);
        }


        s123.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton compoundButton, boolean b) {
                if(b==true)
                {
                    emerg=1;
                    s123.setTextColor(ColorStateList.valueOf(Color.RED));
                    Intent intent=new Intent(getContext(),Exservice.class);
                    getActivity().startService(intent);
                }
                else{
                    emerg=0;
                    s123.setTextColor(Color.parseColor("#20AC00"));
                    Intent intent=new Intent(getContext(),Exservice.class);
                    getActivity().stopService(intent);
                    Toast.makeText(getContext(), "\t\t\tService Stopped \nEmergency Mode -- OFF", Toast.LENGTH_SHORT).show();
                    //Toast.makeText(getContext(), "Emergency Mode -> OFF", Toast.LENGTH_SHORT).show();
                }
            }
        });

        return view;
    }

}
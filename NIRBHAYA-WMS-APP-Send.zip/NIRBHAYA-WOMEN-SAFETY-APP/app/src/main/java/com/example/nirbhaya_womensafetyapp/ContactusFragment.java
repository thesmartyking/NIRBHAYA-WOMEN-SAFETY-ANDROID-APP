package com.example.nirbhaya_womensafetyapp;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Toast;


/**
 * A simple {@link Fragment} subclass.
 */
public class ContactusFragment extends Fragment {


    public ContactusFragment() {
        // Required empty public constructor

    }


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        getActivity().setTitle("CONTACT US");
        View view=inflater.inflate(R.layout.fragment_contactus, container, false);
        view.findViewById(R.id.textView3).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i=new Intent(Intent.ACTION_SEND);
                i.setType("text/html");
                i.putExtra(Intent.EXTRA_EMAIL,"abc@gmail.com");
                i.putExtra(Intent.EXTRA_SUBJECT,"Nibhaya");
                i.putExtra(Intent.EXTRA_TEXT,"Send Mail");
                startActivity(Intent.createChooser(i,"Send Mail"));
            }
        });
        view.findViewById(R.id.textView5).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String dial = "tel:" + "";
                startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse(dial)));
                Toast.makeText(getActivity(),"CALL ON THIS NUMBER TO CONTACT", Toast.LENGTH_SHORT).show();
            }
        });
        //view.findViewById(R.id.textView4).setMovementMethod(LinkMovementMethod.getInstance());
        view.findViewById(R.id.textView4).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String url = "";
                startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse(url)));
            }
        });
        return view;


    }


}